Describe what the app is about.
