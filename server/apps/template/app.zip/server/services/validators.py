from enum import Enum


class Tags(Enum):
    server_health = "Server Health"
